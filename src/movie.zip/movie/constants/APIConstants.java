package movie.constants;

public class APIConstants {
    public static final String REGULAR = "regular";
    public static final String NEW = "new";
    public static final String CHILDREN = "childrens";

}
