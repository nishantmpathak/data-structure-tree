package movie.service;

import movie.model.Customer;

public interface CalculatorService {
    String calculateRent(Customer customer);
}
